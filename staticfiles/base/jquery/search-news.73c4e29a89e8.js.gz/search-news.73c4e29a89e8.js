$(document).ready(function () {
    var availableTags = [];
    alert("help")
    $('#tags').autocomplete({
        source: availableTags
    });
});
