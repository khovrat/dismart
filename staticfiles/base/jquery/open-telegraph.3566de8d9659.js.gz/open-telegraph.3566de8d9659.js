$(document).ready(function() {
  $("#button-telegraph").click(function () {
    $("#link-telegraph").click()[0].click();
  });
});