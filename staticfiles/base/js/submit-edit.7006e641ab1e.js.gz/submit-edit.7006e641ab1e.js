function submitEditUser(){
    document.getElementById('submit-edit-user').click();
}
function submitEditCompany(){
    document.getElementById('submit-edit-company').click();
}